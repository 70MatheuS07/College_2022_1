#ifndef TEMP_H
#define TEMP_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

unsigned int PegaTempo();

#endif