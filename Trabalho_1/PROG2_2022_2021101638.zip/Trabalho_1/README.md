Nome: Matheus de Oliveira Lima.

O desenvolvimento do termo e do termo de dupla foi tranquilo. A partir do momento que começei a mexer com binario meu codigo desandou e começou a ter bugs que nem conversando com os monitores conseguimos resolver. Então já deixo claro, que não utilizei arquivo binário para guardar as informações dos jogadores, utilizei o txt padrão ("jogadores.txt").

Creio que os nomes das funções já dizem oq elas fazem, algumas fazem oq está escrito e até coisa a mais... Mas está comentado com "Doxygen" todas as funções do trabalho.

Inicialmente fiz o termo, depois o termo de dupla, logo na sequência voltei para a main.c para organizar como ficaria o menu. Fiquei agarrado 3 dias tentando resolver o bug dos jogadores.bin (que tem as funções no código ainda em forma de comentario /* */) e então decidi fazer o armazenamento em txt pra conseguir finalizar o trabalho; Mesmo que incompleto por causa dos arquivos em binário.

No mais é isso, boa correção XD.