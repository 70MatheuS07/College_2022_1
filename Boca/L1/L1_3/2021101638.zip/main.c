#include <stdlib.h>
#include <stdio.h>
#include "tData.h"

// Não entendi, porque meu PRINTF nao está imprimindo corretamente...

int main()
{
    int i = 0, n = 0;

    scanf("%d", &n);

    tData *data[n];

    LehData(data, n);

    for (i = 0; i < n; i++)
    {
        CorrigiData(data, n);

        ImprimeData(data, i);

        if (EhBissexto(data, i) == 1)
        {
            printf(":Bisexto\n");
        }
        else
        {
            printf(":Normal\n");
        }
    }

    for(i = 0; i < n; i++)
    {
        free(data[i]);    
    }

    return 0;
}