#ifndef TEMP_H
#define TEMP_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int PegaTempo();

#endif