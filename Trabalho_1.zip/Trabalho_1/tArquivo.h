#ifndef ARQUIVO_H
#define ARQUIVO_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

char **ArmazenaPalavrasArquivo();

void LiberaMatrizArquivo(char **matriz);

void ImprimeMatriz(char **matriz);

void LiberaPalavrasArquivo(char **palavras);

#endif