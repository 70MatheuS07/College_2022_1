#ifndef UFENIXCAT_H
#define UFENIXCAT_H

#include "prototipos.h"
#include <error.h>
#include <stdio.h>
#include <stdlib.h>

void ufenix_cat(FILE *fp);

int mainUfenix_cat(int argc, char **argv);

#endif
